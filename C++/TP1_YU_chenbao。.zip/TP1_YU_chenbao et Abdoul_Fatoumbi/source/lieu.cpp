#include "lieu.h"
using namespace std;
static Lieu* ville[12];
int Lieu::idVille=0;
void destructeur(){
	//Libéré tous les lieu dans ville[12]
	for(int i=0;i<12;i++){
		delete ville[i];
	}
}
bool estAccessible(connectionType_t mt,string l1,string l2){
		int m=-1;
		//D'abord je cherche l'id du ville l1
		for(int i=0;i<12;i++){
			if(ville[i]->getNom() == l1){
					m=ville[i]->getId();
			}
		}
		//Si ville n'existe pas, m reste -1
		if(m==-1) return 0;
		//Je cherche la ville l2
		for(int i=0;i<12;i++){
			if(ville[i]->getNom()== l2){
				//Si le moyen de transport est all
				if(mt==2){
					if(ville[i]->estEnrelation(m)==1 ||ville[i]->estEnrelation(m)==0){
					return 1;
					}
				}
				//Si le moyen de transport est train ou bateau .
				else if(ville[i]->estEnrelation(m)==mt){
					return 1;
				}
			}
		}

		return 0;
}

long distance(connectionType_t mt,string l1,string l2){

	int m=-1,n=-1;
	//Je trouve id de la ville l1 et l2
	for(int i=0;i<12;i++){
		if(ville[i]->getNom() == l1){
			m=ville[i]->getId();
		}
		if(ville[i]->getNom() == l2){
			n=ville[i]->getId();
		}		
	}
	//Si je ne trouve pas, erreur
	if(m==-1 || n==-1){
		//cout<<"La ville n'existe pas !!"<<endl;
		return -1;
	}
	//L'algorithme de Dijkstra version adapté
	int nb=1;
	//0=la ville n'est pas encore visité, 1 =la ville est déjà visité
	bool P[12]={0};
	//1000 est ici = plus infinie pour algorithme de dijkstra
	int Distance[12]={1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000};
	//score=distance, il s'augmente à chaque boucle.
	int score=1;
	//m=ville sommet
	Distance[m]=0;
	P[m]=1;
	
	switch(mt){
	case TRAIN:
	case BATEAU:
		//tant que l2 n'a pas encore une distance, ou score inférieur à 12
		while(Distance[n]==1000 && score<12){
		for(int i=0;i<12;i++){
			//Si la ville a une distance, on vérifie si les villes alentours ont ils une distance.
			if(P[i]==1){
				for(int j=0;j<12;j++){
					if( estAccessible(mt,ville[i]->getNom(),ville[j]->getNom()) && P[j]==0){
					//S'ils ont pas encore, on les donnera une distance 
					P[j]=1;
					Distance[j]=score;
					}
				}
			//Fin d'une boucle while , on incrémente score pour lancer la deuxieme boucle.
			score++;
			}
		}
	}
		/*if(mt==0) cout<<"train uniquement,";
		else if(mt==1) cout<<"bateau uniquement,";*/
		break;
	case ALL:
		while(Distance[n]==1000 && score<12){
		for(int i=0;i<12;i++){
			if(P[i]==1){
				for(int j=0;j<12;j++){
					//ALL=accessible par bateau ou train .
					if( (estAccessible(BATEAU,ville[i]->getNom(),ville[j]->getNom()) ||estAccessible(TRAIN,ville[i]->getNom(),ville[j]->getNom())) && P[j]==0){
					P[j]=1;
					Distance[j]=score;
					}
				}
			score++;
			}
		}
		}
		//cout<<"train ou bateau,";
		break;
	}
	if(Distance[n]==1000)  Distance[n]=-1;
	//cout<<"Distance entre "<<l1<<" et "<<l2<<" est : "<<Distance[n]<<endl;
	return Distance[n];
}
		
int Lieu::estEnrelation(int i){
		if(Vtrain[i]==1 && Vbateau[i]==1) return ALL;
		else if(Vtrain[i]==1) return TRAIN;
		else if(Vbateau[i]==1) return BATEAU;
		else return 3;
	}
void Lieu::addConnexion(connectionType_t mt,ville_t vt){
		switch(mt){
			case BATEAU :{
					//on passe de 0 à 1 pour dire en relation bateau .
					Vbateau[vt]=1;
					NbrTrain++;
					break;
				}
			case TRAIN :{
					Vtrain[vt]=1;
					NbrBateau++;
					break;
				}
			case ALL:{
					Vtrain[vt]=1;
					Vbateau[vt]=1;
					break;
				}
			}
	}
	
void print_connexions(){
	int i;
	cout<<std::setw(12)<<"|";
	for(i=0;i<12;i++){
		cout<<std::setw(12)<<ville[i]->getNom()+"|";
	}
	cout<<endl;
	for(i=0;i<12;i++){
		cout<<std::setw(12)<<ville[i]->getNom()+"|";
		for(int j=0;j<12;j++){
			int temp=ville[i]->estEnrelation(j);
			if(temp==ALL) cout<<std::setw(12)<<"all[2]|";
			else if(temp==TRAIN) cout<<std::setw(12)<<"train[0]|" ;
			else if(temp==BATEAU) cout<<std::setw(12)<<"bateau[1]|";
			else cout<<std::setw(12)<<"aucun[-1]|";
		}
		cout<<endl;
		
		
	}
	cout<<endl;
}
void init(){
	//Je crée les villes
	ville[0]=new Lieu("edimbourg");
	ville[1]=new Lieu("brest");
	ville[2]=new Lieu("plymouth");
	ville[3]=new Lieu("londres");
        ville[4]=new Lieu("douvres");
 	ville[5]=new Lieu("calais");   
 	ville[6]=new Lieu("lehavre");
  	ville[7]=new Lieu("portsmouth");
        ville[8]=new Lieu("quimper");
        ville[9]=new Lieu("rennes");
        ville[10]=new Lieu("paris");
        ville[11]=new Lieu("bordeaux"); 
	
	//J'ajoute les relations
	//Edimbourg
	ville[0]->addConnexion(TRAIN,Londre);
	//Brest
	ville[1]->addConnexion(TRAIN,Rennes);
	ville[1]->addConnexion(BATEAU,Plymouth);
	ville[1]->addConnexion(BATEAU,Bordeaux);
	//Plymouth
	ville[2]->addConnexion(TRAIN,Londre);
	ville[2]->addConnexion(BATEAU,Brest);
	//Londres
	ville[3]->addConnexion(TRAIN,Plymouth);
	ville[3]->addConnexion(TRAIN,Portsmouth);
	ville[3]->addConnexion(TRAIN,Douvres);
	ville[3]->addConnexion(TRAIN,Edimbourg);
	//Douvres
	ville[4]->addConnexion(TRAIN,Londre);
	ville[4]->addConnexion(TRAIN,Calais);
	//Calais
	ville[5]->addConnexion(BATEAU,Douvres);
	ville[5]->addConnexion(TRAIN,Paris);
	//Le Havre
	ville[6]->addConnexion(BATEAU,Portsmouth);
	ville[6]->addConnexion(BATEAU,Paris);
	//Portsmouth
	ville[7]->addConnexion(TRAIN,Londre);
	ville[7]->addConnexion(BATEAU,LeHavre);
	//Quimper
	ville[8]->addConnexion(TRAIN,Rennes);
	ville[8]->addConnexion(TRAIN,Bordeaux);
	//Rennes
	ville[9]->addConnexion(TRAIN,Quimper);
	ville[9]->addConnexion(TRAIN,Brest);
	ville[9]->addConnexion(TRAIN,Paris);
	//Paris
	ville[10]->addConnexion(BATEAU,LeHavre);
	ville[10]->addConnexion(TRAIN,Calais);
	ville[10]->addConnexion(TRAIN,Rennes);
	ville[10]->addConnexion(TRAIN,Bordeaux);
	//Bordeaux
	ville[11]->addConnexion(BATEAU,Brest);
	ville[11]->addConnexion(TRAIN,Quimper);
	ville[11]->addConnexion(TRAIN,Paris);
	

}	
