#include<iostream>
#include <iomanip>
#define Nbr 12

typedef enum{
	TRAIN,
	BATEAU,
	ALL
}connectionType_t;
typedef enum{
	Edimbourg,
	Brest,
	Plymouth,
	Londre,
	Douvres,
	Calais,
	LeHavre,
	Portsmouth,
	Quimper,
	Rennes,
	Paris,	
	Bordeaux
}ville_t;

class Lieu{
	std::string nom;
	bool Vtrain[Nbr]={0};
	bool Vbateau[Nbr]={0};
	
	int NbrTrain=0;//Nombres des villes en relation par train
	int NbrBateau=0;
	
	int id;//Identité de la ville
	public:
	static int idVille;//Incrémenté chaque quand on crée un objet ville
	//Constructeur
		Lieu(std::string name){
			//std::cout<<"La ville:"<<name<<"  est bien crée."<<std::endl;
			nom=name;
			id=idVille;
			idVille++;
		}
	//Destructeur
		~Lieu(){
		}
	//Getteurs
	std::string getNom(){
		return nom;
	}
	int getNbrBateau(){
		return NbrBateau;
	}
	int getNbrTrain(){
		return NbrTrain;
	}
	int getId(){
		return id;
	}

	//Methodes static
	//Methodes
	int estEnrelation(int i);
	void addConnexion(connectionType_t mt,ville_t vt);
};
	void destructeur();
	void init();
	void print_connexions();
	long distance(connectionType_t mt,std::string l1,std::string l2);
	bool estAccessible(connectionType_t mt,std::string l1,std::string l2);
	
