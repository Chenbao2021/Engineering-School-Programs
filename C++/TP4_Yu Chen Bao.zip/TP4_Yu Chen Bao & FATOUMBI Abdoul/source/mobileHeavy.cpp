#include "mobileHeavy.h"

double MobileHeavy::avance(double dt)
	{
		double tempRestant=dt;
		while(tempRestant >0){
			Mobile::avance(0.01);
			tempRestant=tempRestant-0.01;
			vitesse.setZ(vitesse.getZ()+0.01*(-9.81));
		}
		if(position.getZ()<5){
			return position.getZ();
		}else{
			return false;
		}
	}
Mobile* MobileHeavy::copy(){
		return new MobileHeavy(*this);
	}
	

