#ifndef _MOBILEHEAVY
#define _MOBILEHEAVY

#include "mobile.h"
#include<assert.h>
class MobileHeavy:public Mobile
{
	double masse;
	public:
	MobileHeavy(string name,Vector3D _position,Vector3D _vitesse):Mobile(name,_position,_vitesse)
	{}
	double avance(double dt);
	virtual Mobile* copy();

};			



#endif
