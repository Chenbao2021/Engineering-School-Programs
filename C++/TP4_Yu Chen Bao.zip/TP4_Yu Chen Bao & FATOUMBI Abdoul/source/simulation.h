#ifndef _SIMULATION
#define _SIMULATION
#include<iostream>
#include<list>
#include "mobile.h"
#include "mobileHeavy.h"
using namespace std;
class Simulation{
	double time;
	list<Mobile *> bodies;
	list<Mobile *>::iterator i;
	public:
		Simulation(){}
		
		Simulation(const Simulation &a);
		~Simulation();
			
		
		list<Mobile *> getBodies() const;
		
		Mobile* addBody(Vector3D position,Vector3D speed,bool SiHeavy);
		Mobile* addBody(string name,Vector3D position,Vector3D speed,bool SiHeavy);
		bool removeBody(Mobile *m);
		string toString();
		void step(double dt);
		
						
};


#endif
