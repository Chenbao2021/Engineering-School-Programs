void testVector3D();
void testMobile1();
void testMobile2();
void testSimulation1();
void testSimulation2();
void testSimulation3();
