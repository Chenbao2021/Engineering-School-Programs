#ifndef _VECTOR
#define _VECTOR
#include<iostream>
#include<assert.h>
using namespace std;
class Vector3D{
	float x;
	float y;
	float z;
	public:
		float getX() const{return x;} 
		float getY() const{return y;} 
		float getZ() const{return z;}
		void setX(float _x) {x=_x;} 
		void setY(float _y) {y=_y;} 
		void setZ(float _z) {z=_z;}
		Vector3D(float _x,float _y,float _z):x(_x),y(_y),z(_z){}
		Vector3D(const Vector3D &a)
		{
			x=a.getX();
			y=a.getY();
			z=a.getZ();
		}
		~Vector3D(){}
		
		string toString();
		float operator[](int i) const;
		void operator+=(Vector3D const& a);
		void operator=(Vector3D const& a);
};

Vector3D operator+(Vector3D const& a,Vector3D const& b);
ostream& operator<<(ostream& os, const Vector3D& v);
bool operator==(const Vector3D &a,const Vector3D &b);
bool operator!=(const Vector3D &a,const Vector3D &b);
Vector3D operator*(const double i,const Vector3D &v);


#endif
