#include "earth.h"

Earth* Earth::instance=nullptr;
Earth* Earth::getInstance(){
        if(!instance){
            instance=new Earth();
            return instance;
        }
        else{
            cout<<"La terre existe déja"<<endl;
            return instance;
        }
}