#ifndef _EARTH
#define _EARTH
#include "vector3D.h"
#include "mobileHeavy.h"
#include <iostream>
#include <cmath>

class Earth: public MobileHeavy
{
    static Earth *instance;
    Earth():MobileHeavy("Terre",6371008,5514000){}
    //private:evitr des création par copie ou affectation
    bool operator=(const Earth& a){return false;}
    Earth(const Earth &a);
    public:
    ~Earth(){}
    static Earth*getInstance();
 
};







#endif
