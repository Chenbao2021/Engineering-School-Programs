#include "mobile.h"
double Mobile::avance(double dt)
	{
		position+=dt*vitesse;
		return position.getZ();
	
	}
string Mobile::to_string(){
		string str("Mobile:");
		str.append(nom);
		str.append("\nvitesse ");
		str.append(vitesse.toString());
		str.append("position:");
		str.append(position.toString());
		return str;
	}
	
Mobile* Mobile::copy(){
		return new Mobile(nom,position,vitesse);
	}


