#ifndef _MOBILE
#define _MOBILE

using namespace std;
#include "vector3D.h"
class Mobile
{
	protected:
	string nom;
	Vector3D position;
	Vector3D vitesse;
	bool poid;
	public:
	Mobile(string name,float p_x,float p_y,float p_z,float v_x,float v_y,float v_z):nom(name),position(p_x,p_y,p_z),vitesse(v_x,v_y,v_z),poid(false)
	{
	
	}
	Mobile(string name,Vector3D _position,Vector3D _vitesse):nom(name),position(_position),vitesse(_vitesse),poid(false)
	{}
	Mobile(string name):nom(name),position(0,0,0),vitesse(0,0,0),poid(false)
	{
	}
	~Mobile()
	{
	}
	Vector3D getPosition() const
	{
		return position;
	}
	Vector3D getVitesse() const
	{
		return vitesse;
	}
	string getNom() const
	{
		return nom;
	}
	bool getPoid() const
	{
		return poid;
	}
	void setNom(string name) 
	{
		nom=name;
	}
	virtual double avance(double dt);
	string to_string();
	
	virtual Mobile* copy();
	
};

	
#endif
