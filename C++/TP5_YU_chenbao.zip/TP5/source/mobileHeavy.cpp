#include "mobileHeavy.h"
/*Ici,j'ai donné un grand nombre de temps, puis je l'exécute petit à petit
double MobileHeavy::avance(double dt)
	{
		double tempRestant=dt;
		while(tempRestant >0){
			Mobile::avance(0.01);
			tempRestant=tempRestant-0.01;
			vitesse=(vitesse+0.01*(_acceleration));
		}
		return true;
	}
*/	
//Ici , je donne un petite temps et je l'exécute.Version adapté pour dernier test.
double MobileHeavy::avance(double dt)
	{
			vitesse=(vitesse+dt*(_acceleration));
			position+=dt*vitesse;
		return true;
	}
Mobile* MobileHeavy::copy(){
		return new MobileHeavy(*this);
	}
	

void MobileHeavy::computeAcceleration(list<Mobile*> bodies){
    Vector3D F(0,0,0);  
    for(auto i:bodies)   //On parcourt la liste 
    {
    	if(i->getPoid()==true){
		MobileHeavy * H= dynamic_cast<MobileHeavy *>(i);
        	if (H != this) 
		{
        	    F=F+(*H).gravity(this->getPosition()) ; 
            
		}
	}
        i++;
    }
    // Ensuite la somme des forces étant égale à l'accéleration on a 
    _acceleration=F;
}
