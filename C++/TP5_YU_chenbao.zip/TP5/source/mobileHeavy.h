#ifndef _MOBILEHEAVY
#define _MOBILEHEAVY

#include "mobile.h"
#include<assert.h>
#include <list>
#include <cmath>
class MobileHeavy:public Mobile
{
	const double radius;
	const double density;
	Vector3D _acceleration;
	public:
	MobileHeavy(string name,Vector3D _position,Vector3D _vitesse,double rayon,double densite):Mobile(name,_position,_vitesse),radius(rayon),density(densite),_acceleration(0,0,0)
	{
		poid=true;
	}
	MobileHeavy(string name,Vector3D _position,Vector3D _vitesse):Mobile(name,_position,_vitesse),radius(0),density(0),_acceleration(0,0,0)
	{
		poid=true;
	}
	MobileHeavy(string name,double rayon,double densite):Mobile(name),radius(rayon),density(densite),_acceleration(0,0,0)
	{
		poid=true;
	}
	double getRadius(){return radius;}
	double getDensity(){return density;}
	double avance(double dt);
	Vector3D getAcceleration() const
	{
		return _acceleration;
	}
	virtual Mobile* copy();

	double mass()
	{
		return ((4* M_PI *(pow(radius,3)))/3)*density;
	}
	Vector3D gravity(const Vector3D& p) 
	{
		Vector3D dir = p - this->position;
		double d = norm(dir);
		return (-(this->mass() * 6.674e-14)/(d*d*d))*dir;
	}
	void computeAcceleration(std::list<Mobile*> bodies);


};			



#endif
