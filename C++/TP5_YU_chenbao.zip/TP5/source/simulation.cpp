#include "simulation.h"
#include<iostream>
Simulation::Simulation(const Simulation &a){
			time=a.time;
			for(auto j:(a.getBodies())){
				bodies.push_back((*j).copy());
			}
			
			
				
		}
Simulation::~Simulation(){
			i=bodies.begin();
			while(i!= bodies.end()){
				delete *i;
				i++;
			}
			cout<<"La classe est détruit"<<endl;
		}
			
		
list<Mobile *> Simulation::getBodies() const{
			return bodies;			
		}
		
Mobile* Simulation::addBody(Vector3D position,Vector3D speed,bool SiHeavy){
			if(SiHeavy == false){
				Mobile *M=new Mobile("No name",position,speed);
				//on utilise un new ? ou liste des ....?
				bodies.push_back(M);
				return M;
			}else{
				MobileHeavy *M=new MobileHeavy("No name",position,speed);
				//on utilise un new ? ou liste des ....?
				bodies.push_back(M);
				return M;
			}
		}
Mobile* Simulation::addBody(string name,Vector3D position,Vector3D speed,bool SiHeavy){
			if(SiHeavy==false){
				Mobile *M=new Mobile(name,position,speed);
				//on utilise un new ? ou liste des ....?
				bodies.push_back(M);
				return M;
			}else{
				MobileHeavy *M=new MobileHeavy(name,position,speed);
				//on utilise un new ? ou liste des ....?
				bodies.push_back(M);
				return M;
				
		}
		}
Mobile* Simulation::addBody(Mobile* M){
			bodies.push_back(M);
			return M;
}
bool Simulation::removeBody(Mobile *m){
			bodies.remove(m);
			return 1;
		}
string Simulation::toString(){
			string str;
			str.append("Le time courant est:");
			str.append(std::to_string(time));
			str.append(" ,et voici les informations sur les mobiles:\n");
			
			for(auto i:bodies){
				str.append((*i).to_string());
			}
			
			return str;
}
/*
void Simulation::step(double dt){
			if(dt>=0){
				for(auto i:bodies){
					(*i).avance(dt);
				}
				time+=dt;
			}else{
				cout<<"Il ne peut pas avoir un temps négatif!"<<endl;
			}
		}
*/

void Simulation::step(double dt)
{
			if(dt>=0)
			{
				for(auto i:bodies)
				{
					if((*i).getPoid()==true){
						MobileHeavy * H= dynamic_cast<MobileHeavy *>(i);
						(*H).avance(dt); //On utilise la méthode virtual  avance 
						(*H).computeAcceleration(bodies);				
					 }
					 else{
					 	(*i).avance(dt);
					 }
				}
				time+=dt;
			}
			else
			{
				cout<<"Le temps ne peut pas etre  négatif!"<<endl;
			}
}	

void Simulation::simulate(double stop) {
	double time1 = 0.0;
	do{
		this->step(this->time_step);
		time1 += this->time_step;
	}while (time1 < stop);
}//A expliquer


					


