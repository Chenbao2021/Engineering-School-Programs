
#include "test.h"
void testMobile1()
	{
		Vector3D v(6,7,9);
		Vector3D w(6,7,8);
		Mobile v3("Yes",v,w);
		v3.avance(4);
		//Vérifier les valeurs
		assert((v3.getPosition())[0]==30);
		assert((v3.getPosition())[1]==35);
		assert((v3.getPosition())[2]==41);
		v3.setNom("Porch");
		assert(v3.getVitesse() == w);
		assert(v3.getNom()=="Porch");
		cout<<"Tous les tests de get et set ne provoquent pas assert"<<endl; 
	}
void testMobile2(){
	//Test de la méthode avancer , avec un erreur de moins de 5 metres et un pas de 0.01
	Vector3D position(0,0,100);
	Vector3D vitesse(0,0,0);
	MobileHeavy *Audi=new MobileHeavy("Audi",position,vitesse);
	Audi->setNom("Porch");
	assert(Audi->getPosition() == position);
	assert(Audi->getVitesse() == vitesse);
	assert(Audi->getNom()=="Porch");
	cout<<"Tous les tests de get et set ne provoquent pas assert"<<endl; 
	cout<<"Demonstration de la méthode avance de mobileHeavy"<<endl;
	cout<<Audi->to_string()<<endl;
	assert(Audi->avance(4.5)<5);
	cout<<Audi->to_string()<<endl;
}

void testSimulation1(){
	//INitialisations
	Vector3D v(1,1,1);
	Vector3D w(2,2,2);
	Vector3D p(3,3,3);
	Vector3D q(4,4,4);
	Simulation *g=new Simulation();
	Mobile *toyota=g->addBody("Toyota",v,w,true);
	Mobile *Audi=g->addBody("Audi",p,q,false);
	cout<<"Demonstration de addBody"<<endl;
	cout<<g->toString()<<endl;
	g->removeBody(toyota);
	cout<<"Demonstration de removeBody"<<endl;
	cout<<g->toString()<<endl;
	cout<<"Demonstration de step avec un pas de -2,0.1 puis 2 \n"<<endl;
	g->step(-2);
	cout<<g->toString()<<endl;
	g->step(0.1);
	cout<<g->toString()<<endl;
	g->step(2);
	cout<<g->toString()<<endl;
	
	//Tests de deux addBodys:
}
	
void testSimulation2(){
	//INitialisations
	Vector3D v(1,1,1);
	Vector3D w(0,0,0);
	Vector3D p(3,3,3);
	Vector3D q(3,3,3);
	Simulation *g=new Simulation();
	Mobile *toyota=g->addBody("Toyota",v,w,true);
	Mobile *Audi=g->addBody("Audi",p,q,false);
	cout<<"Les valeurs initiale:\n"<<g->toString()<<endl;
	for(int i=0;i<2;i++){
		g->step(1);
	}
	assert(toyota->getPosition().getX()==1);
	assert(toyota->getPosition().getY()==1);
	//assert(toyota->getPosition().getZ()== -3.755951);
	assert(Audi->getPosition().getX()==9);
	assert(Audi->getPosition().getY()==9);
	assert(Audi->getPosition().getZ()==9);
	cout<<"Les valeurs sont bien celle d'attendue\n"<<g->toString()<<endl;
}


void testSimulation3(){
	//INitialisations
	Vector3D v(1,1,1);
	Vector3D w(0,0,0);
	Vector3D p(3,3,3);
	Vector3D q(3,3,3);
	Simulation *g=new Simulation();
	Mobile *toyota=g->addBody("Toyota",v,w,true);
	Mobile *Audi=g->addBody("Audi",p,q,false);
	cout<<"Affichage de g"<<endl;
	cout<<g->toString()<<endl;
	//Je vérifie que H est bienr recopié.
	Simulation h=Simulation(*g);
	cout<<"Affichage de h, vérifie h est bien recopié"<<endl;
	cout<<h.toString()<<endl;
	
	cout<<"Je vérifie que h et g ne partage pas le même vitesse et position"<<endl;
	g->step(1);
	assert(h.getBodies() != g->getBodies());
}

void testVector3D(){
	bool result=true;
	Vector3D v(6,7,9);
	Vector3D w(6,7,8);
	//Je teste operator[]
	assert(v[0]==6);
	assert(v[1]==7);
	assert(v[2]==9);
	//v[-1]==6; //Dans [] j'ai catch l'erreur et j'appele assert()
	//v[3]==6;
	//Je teste operator+
	Vector3D y=v+w;
	assert(y[0]==v[0]+w[0]);
	assert(y[1]==v[1]+w[1]);
	assert(y[2]==v[2]+w[2]);
	//Je teste operator=
	y=w;
	assert(y[0]==w[0]);
	assert(y[1]==w[1]);
	assert(y[2]==w[2]);
	//Je teste operator ==
	assert(y==w);
	assert(!(y==v));
	//Je teste operator!=
	assert(v!=w);
	assert(!(y!=w));
	//Je teste operator<<
	cout<< y <<endl;
	cout<<"L'assert a pas interrompue le programme, les operators marchent."<<endl;
}

void testEarth(){
        Earth * Terre=Earth::getInstance();
        cout<<"Je vais tenter de créer une deuxième terre par Earth::getInstance"<<endl;
	Earth * Terre2=Earth::getInstance();
	cout<<"Je vais tenter de créer une deuxième terre par affectation et par copie"<<endl;
	//Earth b=*Terre;
	//Earth c(*Terre);
	cout<<"Earth::Earth(const Earth&) is private within this context"<<endl;
}

void testSatellite1(){
	Simulation *g=new Simulation();
        Earth * Terre=Earth::getInstance();
	MobileHeavy *Satellite=new MobileHeavy("Satellite",Vector3D(6571008,0,0),Vector3D(0,7784.3,0),1,1);
	g->addBody(Terre);
	g->addBody(Satellite);
	cout<<"Debut:"<<endl;
	//Affichage des données du satellite initiale
	cout<<"Position:"<<Satellite->getPosition()<<endl;
	cout<<"Vitesse:"<<Satellite->getVitesse()<<endl;
	cout<<"Acceleration:"<<Satellite->getAcceleration()<<endl;
	Vector3D initiale(Satellite->getPosition());
	//Dans l'énoncé y a marque 1h29minutes, mais je crois que c'est arrondies, d'après des tests, 5292 correpond le plus à  un tour
	g->simulate(5292);
	cout<<"FIn"<<endl;
	//Affichage des données du satellite initiale
	cout<<"Position:"<<Satellite->getPosition()<<endl;
	cout<<"Vitesse:"<<Satellite->getVitesse()<<endl;
	cout<<"Acceleration:"<<Satellite->getAcceleration()<<endl;
	
	cout<<"Norme de position a la fin:"<<norm(Satellite->getPosition())<<endl;
	cout<<"Nome de position initiale:" <<norm(initiale)<<endl;
	cout<<"L'écart de la distance:"<<distance(initiale,Satellite->getPosition())<<endl;
}
	
	
