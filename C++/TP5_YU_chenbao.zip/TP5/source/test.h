#include "earth.h"
#include "vector3D.h" 
#include "mobile.h" 
#include "simulation.h"
#include "mobileHeavy.h"

void testVector3D();
void testMobile1();
void testMobile2();
void testSimulation1();
void testSimulation2();
void testSimulation3();
void testEarth();
void testSatellite1();
void testSatellite2();
