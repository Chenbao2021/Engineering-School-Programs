#include "vector3D.h"

string Vector3D::toString(){
			string str;
			str.append("x=");
			str.append(std::to_string(x));
			str.append(", y=");
			str.append(std::to_string(y));
			str.append(", z=");
			str.append(std::to_string(z));
			str.append("\n");
			return str;
}

double Vector3D::operator[](int i) const
		{
			try{
				switch(i){
					case 0: return x;
					case 1: return y;
					case 2: return z;
					default: throw("0=x,1=y,2=z!!");
					
				}
			}catch(const char *s){
				cout<<"0=x,1=y,2=z!!"<<endl;
				assert(0);
			}
			return 0;
		}

void Vector3D::operator+=(Vector3D const& a)
		{
			x+=a.getX();
			y+=a.getY();
			z+=a.getZ();
		}
	
void Vector3D::operator=(Vector3D const& a)
		{
			x=a.getX();
			y=a.getY();
			z=a.getZ();
		}
double norm(const Vector3D & a)
{
		return sqrt(pow((a.getX()),2)+pow((a.getY()),2)+pow((a.getZ()),2));
}
double distance(const Vector3D& a ,const Vector3D& b)
{
		return sqrt(pow((a.getX()-b.getX()),2)+pow((a.getY()-b.getY()),2)+pow((a.getZ()-b.getZ()),2));
}



Vector3D operator+(Vector3D const& a,Vector3D const& b)
{
			Vector3D c(a.getX()+b.getX(),a.getY()+b.getY(),a.getZ()+b.getZ());
			return c;
}
Vector3D operator-(Vector3D const& a,Vector3D const& b)
{
			Vector3D c(a.getX()-b.getX(),a.getY()-b.getY(),a.getZ()-b.getZ());
			return c;
}

ostream& operator<<(ostream& os, const Vector3D& v) 
{
	os << "x="<<v.getX() << ',' << "y=" <<v.getY()<<',' <<"z="<<v.getZ()<<"\n";
	return os;
}
bool operator==(const Vector3D &a,const Vector3D &b){
	if(a.getX()==b.getX() && a.getY()==b.getY() && a.getZ()==b.getZ()) return true;
	return false;
}
bool operator!=(const Vector3D &a,const Vector3D &b){
	if(a.getX()!=b.getX() || a.getY()!=b.getY() || a.getZ()!=b.getZ()) return true;
	return false;
}
//On peut faire une template ici?
Vector3D operator*(const double i,const Vector3D &v)
{
	Vector3D c(i*v.getX(),i*v.getY(),i*v.getZ());
	return c;
}
Vector3D operator/(Vector3D const& a,const double i)
{
			Vector3D c(a.getX()/i,a.getY()/i,a.getZ()/i);
			return c;
}


