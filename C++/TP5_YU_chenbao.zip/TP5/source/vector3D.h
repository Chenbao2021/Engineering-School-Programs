#ifndef _VECTOR
#define _VECTOR
#include<iostream>
#include<assert.h>
#include <cmath>
using namespace std;
class Vector3D{
	double x;
	double y;
	double z;
	public:
		double getX() const{return x;} 
		double getY() const{return y;} 
		double getZ() const{return z;}
		void setX(double _x) {x=_x;} 
		void setY(double _y) {y=_y;} 
		void setZ(double _z) {z=_z;}
		Vector3D(double _x,double _y,double _z):x(_x),y(_y),z(_z){}
		Vector3D(const Vector3D &a)
		{
			x=a.getX();
			y=a.getY();
			z=a.getZ();
		}
		~Vector3D(){}
		
		string toString();
		double operator[](int i) const;
		void operator+=(Vector3D const& a);
		void operator=(Vector3D const& a);


};

Vector3D operator+(Vector3D const& a,Vector3D const& b);
Vector3D operator-(Vector3D const& a,Vector3D const& b);
ostream& operator<<(ostream& os, const Vector3D& v);
bool operator==(const Vector3D &a,const Vector3D &b);
bool operator!=(const Vector3D &a,const Vector3D &b);
Vector3D operator*(const double i,const Vector3D &v);
Vector3D operator/(Vector3D const& a,const double i);
double norm(const Vector3D & a);
double distance(const Vector3D& a ,const Vector3D& b);

#endif
