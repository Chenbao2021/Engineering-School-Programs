#include <iostream>
#include "test.h"
#include "scenario.h"
int main(int argc, char** argv) {
//Test Personnage
  testPersonnage();

//TOus les autres tests
  Scenario *sc=new Scenario();
  sc->initScenario();

  sc->carte.print_connexion();
  std::cout << "estAccessible : ";
  if (testEstAccessible(sc))
    std::cout << "OK";
  else
     std::cout << "ERREURS";
  std::cout << std::endl;

  std::cout << "distance : ";
  if (testDistances(sc) )
    std::cout << "OK";
  else
     std::cout << "ERREURS";
  std::cout << std::endl;

  testDeplace(sc);
  return 0;
}

