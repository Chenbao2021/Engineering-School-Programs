

#include<iostream>
#include "personnage.h"



//Consctructeurs
Personnage::Personnage(std::string _nom){
		this->nom=_nom;
		std::cout<<"Bonjour,je suis "+this->nom <<std::endl;
} 
Personnage::Personnage(std::string _nom,Lieu* _lieu){
		this->nom=_nom;
		this->lieu=_lieu;
		std::cout<<"Bonjour,je suis "+this->nom+" et je viens d'arriver en ville:"<<_lieu->getNom() <<std::endl;
}
//Destructeurs
Personnage::~Personnage(){
		std::cout<<"Il n'y a plus rien a faire ici pour moi "+this->nom+".Adieu!"<<std::endl;
	}
void Personnage::parler(const std::string texte){
		std::cout<<this->nom+":"+texte<<std::endl;
}

void Personnage::deplace(connectionType_t mt,const Lieu* l){
	long distance=lieu->distance(mt,*l);
	//Si la distance=-1, c'est a dire l n'est pas accessible par mt.
	if(distance==-1){
		std::cout<<"Zut!Je me suis trompé de mode ,celui-ci ne va pas à "<<l->getNom()<<std::endl;
	}
	else{
		switch(mt){
			case TRAIN:
				std::cout<<"Je suis "<<nom<< " et je suis  a "<< lieu->getNom()<< " ,Je vais à "<<l->getNom()<<" en prenant "<<distance<<" stations de train."<<std::endl;
				break;
			case BATEAU:
				std::cout<<"Je suis "<<nom<< " et je suis  a "<< lieu->getNom()<<" ,Je vais à "<<l->getNom()<<" en prenant "<<distance<<" stations de BATEAU."<<std::endl;
				break;	
			case ALL:
				std::cout<<"Je suis "<<nom<< " et je suis  a "<< lieu->getNom()<<" ,Je vais à "<<l->getNom()<<" en prenant "<<distance<<" stations de BATEAU ou TRAIN."<<std::endl;
		}
		//A la fin de deplacement, on arrive dans la nouvelle ville .
		lieu=(Lieu *)l;
	}
	
}
