#ifndef _PERSONNAGE
#define _PERSONNAGE

#include <string>
#include <iostream>
#include "lieu.h"
class Personnage{
	std::string nom;
	Lieu* lieu;
	public:
	Personnage(std::string _nom);
	Personnage(std::string _nom,Lieu* lieu);
	~Personnage();
	//Méthodes
	void parler(const std::string texte);
	void deplace(connectionType_t mt,const Lieu* l);
};

#endif




