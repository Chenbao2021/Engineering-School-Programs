#include "scenario.h"

Scenario::Scenario(){
	personnages=(Personnage**)std::malloc(Nbr * sizeof(Personnage*));
}

void Scenario::initPersonnages(){
	std::cout<<"\nInitialisation de l'objet Scenario"<<std::endl;
	personnages[0]=new Personnage("YU",carte.lieu[0]);
	personnages[1]=new Personnage("Fatoumbi",carte.lieu[0]);
	
};
void Scenario::initCarte(){
	//INITIALISATION DES VILLES
	carte.addLieu("edimbourg");
	carte.addLieu("brest");
	carte.addLieu("plymouth");
	carte.addLieu("londres");
        carte.addLieu("douvres");
 	carte.addLieu("calais");   	
 	carte.addLieu("lehavre");
  	carte.addLieu("portsmouth");
        carte.addLieu("quimper");
        carte.addLieu("rennes");
        carte.addLieu("paris");
        carte.addLieu("bordeaux"); 
        carte.addLieu("cherbourg");
	carte.addLieu("Villetaneuse");
	
	//AddConnexions
	carte.addConnexion(TRAIN,carte.lieu[0],carte.lieu[3]);
	carte.addConnexion(TRAIN,carte.lieu[3],carte.lieu[2]);
	carte.addConnexion(TRAIN,carte.lieu[3],carte.lieu[7]);
	carte.addConnexion(TRAIN,carte.lieu[3],carte.lieu[4]);
	carte.addConnexion(TRAIN,carte.lieu[1],carte.lieu[9]);
	carte.addConnexion(TRAIN,carte.lieu[9],carte.lieu[10]);
	carte.addConnexion(TRAIN,carte.lieu[9],carte.lieu[8]);
	carte.addConnexion(TRAIN,carte.lieu[8],carte.lieu[11]);
	carte.addConnexion(TRAIN,carte.lieu[11],carte.lieu[10]);
	carte.addConnexion(TRAIN,carte.lieu[10],carte.lieu[5]);
	
	
	carte.addConnexion(BATEAU,carte.lieu[2],carte.lieu[1]);
	carte.addConnexion(BATEAU,carte.lieu[7],carte.lieu[6]);
	carte.addConnexion(BATEAU,carte.lieu[6],carte.lieu[10]);
	carte.addConnexion(BATEAU,carte.lieu[4],carte.lieu[5]);
	carte.addConnexion(BATEAU,carte.lieu[1],carte.lieu[11]);

}

	
