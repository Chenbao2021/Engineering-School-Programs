#ifndef _SCENARIO
#define _SCENARIO


#include "carte.h"
#include "personnage.h" 

class Scenario{
	long nbPers;
	
	
	public:
		Personnage** personnages;
		Carte carte;
		Scenario();
		long getNbPers(){
			return nbPers;
		}
		Personnage* personnage(long i){
		 	return personnages[i];
		 }
		 void initScenario(){
			initCarte();
			initPersonnages();
		 }
		 void initCarte();
		 void initPersonnages();
};
		
#endif
