#include "test.h"
#include "scenario.h"


void testPersonnage(){
	  std::cout<<"\nTest de Personnage:"<<std::endl;
	  Personnage *p=new Personnage("yu");
  	  p->~Personnage();
}
bool testEstAccessible(Scenario *sc){
  std::cout<<"\nTest de EstAccessible:"<<std::endl;
  bool result = true;
  result &= sc->carte.lieu[7]->estAccessible(connectionType_t ::BATEAU,*sc->carte.lieu[6]);
  result &= !(sc->carte.lieu[7]->estAccessible(connectionType_t ::BATEAU,*sc->carte.lieu[12]));
  result &= sc->carte.lieu[2]->estAccessible(connectionType_t ::ALL,*sc->carte.lieu[1]);
  result &= !(sc->carte.lieu[2]->estAccessible(connectionType_t ::ALL,*sc->carte.lieu[8]));
  result &= sc->carte.lieu[0]->estAccessible(connectionType_t ::TRAIN,*sc->carte.lieu[3]);
  result &= !(sc->carte.lieu[10]->estAccessible(connectionType_t ::TRAIN,*sc->carte.lieu[8]));
  return result;
}


bool testDistances(Scenario *sc){
  std::cout<<"\nTest de Distance:"<<std::endl;
  bool result = true;
  result &= sc->carte.lieu[10]->distance(connectionType_t::TRAIN,*sc->carte.lieu[10])==0;
  result &= sc->carte.lieu[1]->distance(connectionType_t::TRAIN,*sc->carte.lieu[5])==3;
  result &= sc->carte.lieu[3]->distance(connectionType_t::TRAIN,*sc->carte.lieu[10])==-1;
  result &= sc->carte.lieu[10]->distance(connectionType_t::ALL,*sc->carte.lieu[13])==-1;

  result &= sc->carte.lieu[11]->distance(connectionType_t::BATEAU,*sc->carte.lieu[1])==1;
  result &= sc->carte.lieu[11]->distance(connectionType_t::TRAIN,*sc->carte.lieu[1])==3;
  result &= sc->carte.lieu[11]->distance(connectionType_t::ALL,*sc->carte.lieu[1])==1;
  return result;
}
void testDeplace(Scenario *sc){
  std::cout<<"\nTest de la méthode deplacer"<<std::endl;
  sc->personnages[0]->deplace(ALL,sc->carte.lieu[8]);
  sc->personnages[0]->deplace(ALL,sc->carte.lieu[2]);
  sc->personnages[0]->deplace(BATEAU,sc->carte.lieu[11]);
  sc->personnages[0]->deplace(TRAIN,sc->carte.lieu[0]);
}
