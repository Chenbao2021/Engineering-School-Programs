#ifndef _TEST_H
#define _TEST_H

#include "lieu.h"
#include "scenario.h"

void testPersonnage();
void testDeplace(Scenario *sc);
bool testEstAccessible(Scenario *sc);
bool testDistances(Scenario *sc);

#endif
