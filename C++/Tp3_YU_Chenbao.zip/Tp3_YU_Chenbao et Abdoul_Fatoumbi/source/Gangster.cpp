#include "Gangster.h"
#include "Pigeon.h"
#include <ctime>
Gangster::Gangster(std::string nomp,std::string nomGang,Lieu* l):Personnage(nomp),nom_du_gang(nomGang)
{
    lieu=l;
    this->recompense=rand()%11;
    std::cout<<"Je suis "+this->getNom()+" membre du gang "+ this->getNomGang()<<std::endl;
}
std::string Gangster::getNomGang()
{
    return this->nom_du_gang;
}
void Gangster::setNomGang(std::string b)
{
    this->nom_du_gang=b;
}
void Gangster::setrecompense(int b)
{
    recompense=b;
}
Gangster::~Gangster()
{

}
int Gangster::getrecompense()
{
    return recompense;
}
void Gangster::augmenteRecompense(int i)
{
    recompense+=i;
}
void Gangster::effaceRecompense(){
	recompense=0;
}
void Gangster::emprisonne(){
	std::cout<<"Je suis innocent!!"<<std::endl;
	en_prison=true;
}
void Gangster::evade(){
	std::cout<<"Enfin ,free!" <<std::endl;
	en_prison=false;
}

int Gangster::interagit(Personnage &p)
{
	srand(time(NULL));
	if(typeid(p).name()==typeid(Pigeon).name()){
		int a=rand()%2;
		if(a==1) std::cout<<"Hey, "<<p.getNom()<<", ça te dirait de participer à mon culte du jus d’ananas ?" <<std::endl;
		else std::cout<<"Hey," <<p.getNom()<<", Vient voir ma mine de charbon, on y est confortable!"<<std::endl; 
		Pigeon* v=static_cast<Pigeon*>(&p);
		if(v->sefaitvoler<2){
			v->subirVol();
		}
	}
	if(typeid(p).name()==typeid(Gangster).name()){
		Gangster* v=static_cast<Gangster*>(&p);
		if(nom_du_gang == v->getNomGang() && recompense<v->getrecompense()  ){
			std::cout<<"Mes respects, "<<v->getNom()<<" - dono. "<<std::endl;
		}
		else if (nom_du_gang == v->getNomGang() && recompense>v->getrecompense()){
			std::cout<< "Mes respects, "<<nom<<" - dono. "<<std::endl;
		}
	}
	
	return recompense;
}

bool Gangster::getPrison(){
	return en_prison;
}
