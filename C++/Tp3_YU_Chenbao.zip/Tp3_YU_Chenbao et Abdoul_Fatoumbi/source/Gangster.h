#ifndef _GANGSTER
#define _GANGSTER
#include "personnage.h"
#include <stdlib.h>
using namespace std;
class Gangster :public Personnage 
{
    int recompense;
    std::string nom_du_gang;
    bool en_prison=false;
    public :
    Gangster(std::string nomp,std::string nomG,Lieu* l);
    std::string getNomGang();
    void setNomGang(std::string b);
    ~Gangster();
    int getrecompense();
    void setrecompense(int b);
    int interagit(Personnage &p);
   	
   	
    void augmenteRecompense(int i);
    void effaceRecompense();

    void emprisonne();
    void evade();
    
    bool getPrison();
};




#endif
