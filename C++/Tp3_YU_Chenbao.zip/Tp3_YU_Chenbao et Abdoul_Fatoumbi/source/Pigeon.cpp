#include "Pigeon.h"

Pigeon::Pigeon(std::string nompige,Lieu* l):Personnage(nompige,l)
{
       argent=rand()%1001;
        cout<<"Je suis "+getNom()+" et je suis riche "<<endl;
}

int Pigeon::subirVol(){
      if(sefaitvoler<2){
    	cout<<"OK :)"<<endl;
    	argent=argent-rand()%argent;
    	sefaitvoler++;
    	return 1;
      }
      else{
      		cout<<"Sale voleur!!"<<endl;
      }
    	int position;
    	for (int i=0;i<itineraire.size();i++)
	{
		if(lieu->getNumero()==itineraire[i]->getNumero())
		{
			position=i;
		}
	}
	//estvole[position]=true;
	return 0;
}

 void Pigeon::oublierVol(){
    	int position;
    	for (int i=0;i<itineraire.size();i++)
	{
		if(lieu->getNumero()==itineraire[i]->getNumero())
		{
			position=i;
		}
	}
    	if(position-3<0){
    		position=itineraire.size()-position+3;
    	}
    	estvole[position]=false;
    	sefaitvoler--;
    }
