#ifndef _PIGEON
#define _PIGEON
#include "personnage.h"
#include <stdlib.h>
using namespace std;
class Pigeon:public Personnage 
{
    int argent;
    public:
    vector <bool> estvole ;
    int sefaitvoler=0;
    Pigeon(std::string nompige,Lieu* l);
    int getsommeArgent()
    {
        return argent;
    }
    ~Pigeon()
    {

    }

    int interagit(Personnage &p){return 0;}
    int subirVol();
    void oublierVol();  
};


#endif
