#include "Policier.h"

Policier::Policier(std::string nompolicier,Lieu *l):Personnage(nompolicier,l)
{
        reputation=rand()%11;  //Réputation du policier 
        cout<<"Je suis policier "+getNom()+" et j'assure la sécurité de "+lieu->getNom() <<endl;
}

int Policier::interagit(Personnage& p)
    {
        if(typeid(p).name()==typeid(Gangster).name())
        {
            std::cout<<p.getNom()+" Sortez les mains en l'air "<<std::endl;
            Gangster* v=static_cast<Gangster*>(&p);
            if(getReputation()>v->getrecompense())
            {
                    v->effaceRecompense();
                    incrementePopularite();
                    cout<<v->getNom()+" Je vous arrete, vous avez le droit de garder le silence "<<endl;
                     return v->getrecompense();//Si c'est arreté, on retourne la recompense
            }
            else
            {
                decrementePopularite();
                cout<<" Tu crois vraiment pouvoir vaincre le gang "+v->getNomGang()<<"?"<<endl;
                v->augmenteRecompense(2);
                return v->getrecompense();
            }
        }
        return 0;
    }
