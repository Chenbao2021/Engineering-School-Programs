#ifndef _POLICIER
#define _POLICIER
#include "personnage.h"
#include "Gangster.h"
#include <stdlib.h>

class Policier :public Personnage 
{
    int reputation;
    public:
    Policier(std::string nompolicier,Lieu *l);
    int getReputation()
    {
        return reputation;
    }
    void setReputation(int i)
    {
        reputation=i;
    }
    ~Policier()
    {

    }
    int interagit(Personnage& p);
    
    void incrementePopularite()
    {
        reputation++;
    }
    void decrementePopularite()
    {
        reputation--;
    }

};


#endif
