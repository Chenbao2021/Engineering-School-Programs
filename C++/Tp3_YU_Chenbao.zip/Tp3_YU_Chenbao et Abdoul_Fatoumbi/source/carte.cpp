#include "carte.h"

extern  Lieu** ville;

void  Carte::getNom(){
	std::cout<< name<<std::endl;
}
	
Lieu* Carte::addLieu(std::string name){
		Lieu *temp=new Lieu(name);
		ville[nbVilles]=temp;
		lieu[nbVilles]=temp;
		nbVilles++;
		return temp;
}

Lieu* Carte::getLieu(std::string name){
		for(int i=0;i<nbVilles;i++){
			if(lieu[i]->getNom()==name){
				return lieu[i];
			}
		}
		std::cout<<"Aucune ville ne correspond à ce nom."<<std::endl;
		return 0;
}

void Carte::addConnexion(connectionType_t mt,Lieu *l1,Lieu *l2){
		l1->addConnexion(mt,l2);
		l2->addConnexion(mt,l1);
	}
	
void Carte::removeConnexion(connectionType_t mt,Lieu *l1,Lieu *l2){
		l1->removeConnexion(mt,l2);
		l2->removeConnexion(mt,l1);
};
void Carte::print_connexion(){	
	int i;
	std::cout<<std::setw(12)<<"|";
	for(i=0;i<12;i++){
		std::cout<<std::setw(12)<<lieu[i]->getNom()+"|";
	}
	std::cout<<std::endl;
	for(i=0;i<12;i++){
		std::cout<<std::setw(12)<<lieu[i]->getNom()+"|";
		for(int j=0;j<12;j++){
			int temp=lieu[i]->estEnrelation(lieu[j]);
			if(temp==ALL) std::cout<<std::setw(12)<<"all[2]|";
			else if(temp==TRAIN) std::cout<<std::setw(12)<<"train[0]|" ;
			else if(temp==BATEAU) std::cout<<std::setw(12)<<"bateau[1]|";
			else std::cout<<std::setw(12)<<"aucun[-1]|";
		}
		std::cout<<std::endl;
		
		
	}
	std::cout<<std::endl;
}
Carte::Carte(std::string nom){
	name=nom;
	lieu=(Lieu**)malloc(24 * sizeof(Lieu*));
}	
