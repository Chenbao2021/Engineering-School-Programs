#ifndef _CARTE
#define _CARTE

#include "lieu.h"
class Carte{
	std::string name;
	long nbVilles=0;
	public:
	Lieu**	lieu;
	Carte(std::string nom="TP2");
	void allouer();
	void  getNom();
	Lieu *addLieu(std::string name);
	Lieu *getLieu(std::string name);
	void addConnexion(connectionType_t mt,Lieu *l1,Lieu *l2);
	void removeConnexion(connectionType_t mt,Lieu *l1,Lieu *l2);
	
	void print_connexion();
};

#endif
