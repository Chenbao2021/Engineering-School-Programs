#include "lieu.h"
using namespace std;

Lieu** ville=(Lieu**)std::malloc(Nbr * sizeof(Lieu*));
int Lieu::idVille=0;
bool Lieu::estAccessible(connectionType_t mt,const Lieu& l){
		//Je cherche la ville l2 dans le type mt
		switch(mt){
			case TRAIN:
				for(int i=0;i<nbTrain;i++){
					if(train[i]==&l){
						return 1;
					}
				}
				break;
			case BATEAU:
				for(int i=0;i<nbBateau;i++){
					if(bateau[i]==&l){
						return 1;
					}
				}
				break;
						
			case ALL:
				for(int i=0;i<nbTrain;i++){
					if(train[i]==&l){
						return 1;
					}
				}
				for(int i=0;i<nbBateau;i++){
					if(bateau[i]==&l){
						return 1;
					}
				}
				break;
		}
		return 0;
}

long Lieu::distance(connectionType_t mt,const Lieu& l){
	//L'algorithme de Dijkstra version adapté
	int nb=1;
	//0=la ville n'est pas encore visité, 1 =la ville est déjà visité
	bool P[Nbr]={0};

	//1000 est ici = plus infinie pour algorithme de dijkstra
	int Distance[Nbr];
	for(int i=0;i<Nbr;i++) Distance[i]=1000;
	//score=distance, il s'augmente à chaque boucle.
	int score=1;
	//m=ville sommet
	Distance[numero]=0;
	P[numero]=1;
	
	switch(mt){
	case TRAIN:
		while(Distance[l.getNumero()]==1000 && score<Nbr){
		bool temp[Nbr]={0};
		for(int i=0;i<Nbr;i++){
			if(P[i]==1){
				temp[i]=1;
			}
		}
		for(int i=0;i<Nbr;i++){
			if(temp[i]==1){
				for(int j=0;j<Nbr;j++){
					//ALL=accessible par bateau ou train .
					if( ville[i]->estAccessible(TRAIN,*(ville[j]))  && P[j]==0){
					P[j]=1;
					Distance[j]=score;
					}
				}
			}
		}
		score++;
		}
		break;
	case BATEAU:
		while(Distance[l.getNumero()]==1000 && score<Nbr){
		bool temp[Nbr]={0};
		for(int i=0;i<Nbr;i++){
			if(P[i]==1){
				temp[i]=1;
			}
		}
		for(int i=0;i<Nbr;i++){
			if(temp[i]==1){
				for(int j=0;j<Nbr;j++){
					//ALL=accessible par bateau ou train .
					if( ville[i]->estAccessible(BATEAU,*(ville[j]))  && P[j]==0){
					P[j]=1;
					Distance[j]=score;
					}
				}
			}
		}
		score++;
		}
		break;
	case ALL:
		while(Distance[l.getNumero()]==1000 && score<Nbr){
		bool temp[Nbr]={0};
		for(int i=0;i<Nbr;i++){
			if(P[i]==1){
				temp[i]=1;
			}
		}
		for(int i=0;i<Nbr;i++){
			if(temp[i]==1){
				for(int j=0;j<Nbr;j++){
					//ALL=accessible par bateau ou train .
					if( ville[i]->estAccessible(ALL,*(ville[j]))  && P[j]==0){
					P[j]=1;
					Distance[j]=score;
					}
				}
			}
		}
		score++;
		}
		//cout<<"train ou bateau,";
		break;
	}
	if(Distance[l.getNumero()]==1000)  Distance[l.getNumero()]=-1;
	//cout<<"Distance entre "<<l1<<" et "<<l2<<" est : "<<Distance[n]<<endl;
	return Distance[l.getNumero()];
}
		
int Lieu::estEnrelation(Lieu* l){
	int m=-1,n=-1;
	for(int i=0;i<nbBateau;i++){
		if(bateau[i]==l){
			m=1;
		}
	}
	for(int j=0;j<nbTrain;j++){
		if(train[j]==l){
			n=1;
		}
	}
	if(m==1 && n==1) return ALL;
	else if(m==1) return BATEAU;
	else if(n==1) return TRAIN;
	else return -1;
}

void Lieu::addConnexion(connectionType_t mt,Lieu* l){
		switch(mt){
			case BATEAU :{
					bateau[nbBateau]=l;
					nbBateau++;
					break;
				}
			case TRAIN :{
					train[nbTrain]=l;
					nbTrain++;
					break;
				}
			case ALL:{
					train[nbTrain]=l;
					bateau[nbBateau]=l;
					nbBateau++;
					nbTrain++;
					break;
				}
			}
}

void Lieu::removeConnexion(connectionType_t mt,Lieu* l){
			switch(mt){
			case ALL: 
				removeConnexion(TRAIN,l);
				removeConnexion(BATEAU,l);
				break;
			case BATEAU :
					for(int i=0;i<nbBateau;i++){
						if(bateau[i]==l){
							for(int j=i;j<nbBateau;j++){
								bateau[j]=bateau[j+1];
							}
							nbBateau-=1;
						}
					}
					break;
			case TRAIN :
					for(int i=0;i<nbTrain;i++){
						if(bateau[i]==l){
							for(int j=i;j<nbTrain;j++){
								bateau[j]=bateau[j+1];
							}
						}	
						nbTrain-=1;
					}
					break;
				
			}
}

void destructeur(){
	//Libéré tous les lieu dans ville[12]
	for(int i=0;i<12;i++){
		delete ville[i];
	}
}

	

