#ifndef _LIEU
#define _LIEU

#include<iostream>
#include <iomanip>
#define Nbr 24

typedef enum{
	TRAIN,
	BATEAU,
	ALL
}connectionType_t;


class Lieu{
	std::string nom;
	Lieu* train[Nbr];
	//Lieu** train;
	Lieu* bateau[Nbr];
	
	long nbTrain=0;//Nombres des villes en relation par train
	long nbBateau=0;
	
	long numero;//Identité de la ville
	public:
	static int idVille;//Incrémenté chaque quand on crée un objet ville
	//Constructeur
		Lieu(){
			nom="nulle part";
			numero=idVille;
			idVille++;
		}
		Lieu(std::string name){
			//std::cout<<"La ville:"<<name<<"  est bien crée."<<std::endl;
			nom=name;
			numero=idVille;
			idVille++;
		}
	//Destructeur
		~Lieu(){
		}
	//Getteurs
	std::string getNom() const {
		return nom;
	}
	int getNbrBateau() const {
		return nbBateau;
	}
	int getNbrTrain() const {
		return nbTrain;
	}
	int getNumero() const {
		return numero;
	}

	//Methodes static
	//Methodes
	int estEnrelation(Lieu *l);
	void addConnexion(connectionType_t mt,Lieu* l);
	void removeConnexion(connectionType_t mt,Lieu* l);
	long distance(connectionType_t mt,const Lieu&);
	bool estAccessible(connectionType_t mt,const Lieu&);
	void print_relationB(){
		for(int i=0;i<nbTrain;i++){
			std::cout<<train[i]->getNom()<<std::endl;
		}
	}
};
extern  Lieu** ville;
void destructeur();
void init();

#endif
