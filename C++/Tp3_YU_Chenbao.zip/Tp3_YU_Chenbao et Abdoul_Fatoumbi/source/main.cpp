#include <iostream>
#include "test.h"
#include "scenario.h"
#include "Policier.h"
#include "Pigeon.h"
#include "Gangster.h"

using namespace std;
int main(int argc, char** argv) {
  Scenario *sc=new Scenario();   
  cout<<testEstAccessible(sc)<<endl;
  testDeplace(sc);
  Policier *p=new Policier("YU",sc->carte.lieu[10]);
  Gangster *g=new Gangster("YU","Dong",sc->carte.lieu[10]);
  Pigeon *pi=new Pigeon("YU",sc->carte.lieu[10]);
  cout<<testGangster(*g)<<endl;
  cout<<testPolicier(*p)<<endl;
  cout<<testPigeon(*pi)<<endl;
  cout<<testScenario(*sc)<<endl;
  
  return 0;
}

