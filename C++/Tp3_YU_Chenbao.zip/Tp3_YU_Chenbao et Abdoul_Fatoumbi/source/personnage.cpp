#include<iostream>
#include "personnage.h"



//Consctructeurs
Personnage::Personnage(std::string _nom){
		this->nom=_nom;
} 
Personnage::Personnage(std::string _nom,Lieu* _lieu){
		this->nom=_nom;
		this->lieu=_lieu;

}
std::string Personnage::getNom()
{
	return this->nom;
}
void Personnage::setNom(std::string h)
{
	this->nom=h;
}
//Destructeurs
Personnage::~Personnage(){
		std::cout<<"Il n'y a plus rien a faire ici pour moi "+this->nom+".Adieu!"<<std::endl;
	}
void Personnage::parler(const std::string texte){
		std::cout<<this->nom+":"+texte<<std::endl;
}

bool Personnage::deplace(connectionType_t mt,const Lieu* l){
	long distance=lieu->distance(mt,*l);
	//Si la distance=-1, c'est a dire l n'est pas accessible par mt.
	if(distance==-1){
		std::cout<<"Zut!Je me suis trompé de mode ,celui-ci ne va pas à "<<l->getNom()<<std::endl;
		return false;
	}
	else{
		switch(mt){
			case TRAIN:
				std::cout<<"Je suis "<<nom<< " et je suis  a "<< lieu->getNom()<< " ,Je vais à "<<l->getNom()<<" en prenant "<<distance<<" stations de train."<<std::endl;
				break;
			case BATEAU:
				std::cout<<"Je suis "<<nom<< " et je suis  a "<< lieu->getNom()<<" ,Je vais à "<<l->getNom()<<" en prenant "<<distance<<" stations de BATEAU."<<std::endl;
				break;	
			case ALL:
				std::cout<<"Je suis "<<nom<< " et je suis  a "<< lieu->getNom()<<" ,Je vais à "<<l->getNom()<<" en prenant "<<distance<<" stations de BATEAU ou TRAIN."<<std::endl;
		}
		//A la fin de deplacement, on arrive dans la nouvelle ville .
		lieu=(Lieu *)l;
		return true;
	}
	
}
int Personnage::deplace()
{
	int position;
	for (int i=0;i<itineraire.size();i++)
	{
		if(lieu->getNumero()==itineraire[i]->getNumero())
		{
			position=i;
		}
	}
	std::cout<<"Je suis "<<nom<< " et je suis  a "<< lieu->getNom()<< " ,Je vais à " <<itineraire[(position+1)%(itineraire.size())]->getNom()<<std::endl;

	//A la fin de deplacement, on arrive dans la nouvelle ville .
	lieu=itineraire[(position+1)%(itineraire.size())];
	return lieu->getNumero();	
}

int Personnage::interagit(Personnage &p){ return 0;}

void Personnage::interagit(Personnage **ps, int nb_personnes){
	for(int i=0;i<nb_personnes;i++){
		if(ps[i]->lieu->getNom() == lieu->getNom())
			interagit(*ps[i]);
	}
}
