#ifndef _PERSONNAGE
#define _PERSONNAGE
#include <vector>
#include <string>
#include <iostream>
#include "lieu.h"
using namespace std;
class Personnage{
	public:
	vector <Lieu *> itineraire ;
	std::string nom;
	Lieu* lieu;
	Personnage(std::string _nom);
	Personnage(std::string _nom,Lieu* lieu);
	~Personnage();
	//Méthodes
	void parler(const std::string texte);
	bool deplace(connectionType_t mt,const Lieu* l);
	int deplace();
	std::string getNom();
	void setNom(std::string h);
	virtual void interagit(Personnage **ps, int nb_personnes);
	virtual int interagit(Personnage &p);
};

#endif




