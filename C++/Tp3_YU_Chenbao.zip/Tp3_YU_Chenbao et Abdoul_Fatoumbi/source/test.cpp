#include "test.h"
#include "scenario.h"
#include "Policier.h"
#include "Gangster.h"
#include "Pigeon.h"

using namespace std;

void testPersonnage(){
	  std::cout<<"\nTest de Personnage:"<<std::endl;
	  Personnage *p=new Personnage("yu");
  	  p->~Personnage();
}
bool testEstAccessible(Scenario *sc){
  std::cout<<"\nTest de EstAccessible:"<<std::endl;
  bool result = true;
  result &= sc->carte.lieu[7]->estAccessible(connectionType_t ::BATEAU,*sc->carte.lieu[6]);
  result &= !(sc->carte.lieu[7]->estAccessible(connectionType_t ::BATEAU,*sc->carte.lieu[12]));
  result &= sc->carte.lieu[2]->estAccessible(connectionType_t ::ALL,*sc->carte.lieu[1]);
  result &= !(sc->carte.lieu[2]->estAccessible(connectionType_t ::ALL,*sc->carte.lieu[8]));
  result &= sc->carte.lieu[0]->estAccessible(connectionType_t ::TRAIN,*sc->carte.lieu[3]);
  result &= !(sc->carte.lieu[10]->estAccessible(connectionType_t ::TRAIN,*sc->carte.lieu[8]));
  return result;
}


bool testDistances(Scenario *sc){
  std::cout<<"\nTest de Distance:"<<std::endl;
  bool result = true;
  result &= sc->carte.lieu[10]->distance(connectionType_t::TRAIN,*sc->carte.lieu[10])==0;
  result &= sc->carte.lieu[1]->distance(connectionType_t::TRAIN,*sc->carte.lieu[5])==3;
  result &= sc->carte.lieu[3]->distance(connectionType_t::TRAIN,*sc->carte.lieu[10])==-1;
  result &= sc->carte.lieu[10]->distance(connectionType_t::ALL,*sc->carte.lieu[13])==-1;

  result &= sc->carte.lieu[11]->distance(connectionType_t::BATEAU,*sc->carte.lieu[1])==1;
  result &= sc->carte.lieu[11]->distance(connectionType_t::TRAIN,*sc->carte.lieu[1])==3;
  result &= sc->carte.lieu[11]->distance(connectionType_t::ALL,*sc->carte.lieu[1])==1;
  return result;
}
bool testDeplace(Scenario *sc){
  bool result=true;
  std::cout<<"\nTest de la méthode deplacer"<<std::endl;
  result &= sc->personnages[0]->deplace(ALL,sc->carte.lieu[8]);
  result &=sc->personnages[0]->deplace(ALL,sc->carte.lieu[2]);
  result &=sc->personnages[0]->deplace(BATEAU,sc->carte.lieu[11]);
  result &=sc->personnages[0]->deplace(TRAIN,sc->carte.lieu[0]);
  return result;
}



bool testPolicier(Policier& p){
	 std::cout<<"\nTest de la classe Policier"<<std::endl;
	 bool result=true;
 	
	 /*
		Je teste si la popularité initiale est entre 0 et 10 et si les méthodes incrementePopularite et decrementePopularite fonctionne;
	 */


	 
	int reputationI=p.getReputation();
 	 result &= 0<=p.getReputation() && p.getReputation()<=10;
 	 if(!result){
 	 	cout<<"Vous avez une réputation anormale "<<endl;
 	 	return 0;
 	 }
 	 p.incrementePopularite();
 	 result &= reputationI+1 == p.getReputation();
 	  	 if(!result){
 	 	cout<<"Des problèmes dans incrementrePopularité "<<endl;
 	 	return 0;
 	 }
 	 p.decrementePopularite();
 	 result &= reputationI == p.getReputation();
 	  if(!result){
 	 cout<<"Des problèmes dans decrementrePopularité "<<endl;
 	 	return 0;
 	 }
 		
 	 return result;
 	 	
}

bool testGangster(Gangster & p){
	 std::cout<<"\nTest de la classe Gangster"<<std::endl;
	 bool result=true;
 	
	 /*
		Je teste si la popularité initiale est entre 0 et 10 et si les méthodes incrementePopularite et decrementePopularite fonctionne;
	 */


	 
	int recompense=p.getrecompense();
 	 result &= 0<=p.getrecompense() && p.getrecompense()<=10;
 	 if(!result){
 	 	cout<<"Vous avez une réputation anormale "<<endl;
 	 	return 0;
 	 }
 	 p.augmenteRecompense(10);
 	 result &= recompense+10 == p.getrecompense();
 	  	 if(!result){
 	 	cout<<"Des problèmes dans augmenteRecompense "<<endl;
 	 	return 0;
 	 }
 	 p.effaceRecompense();
 	 result &=  p.getrecompense()==0;
 	  if(!result){
 	 cout<<"Des problèmes dans effaceRecompense"<<endl;
 	 	return 0;
 	 }
 	 p.emprisonne();
 	 result &= p.getPrison()==true;
 	 p.evade();
 	 result &= p.getPrison()==false;
 	 if(!result){
 	 	cout<<"Des problèmes dans emprisonne ou evade"<<endl;
 	 	return 0;
 	 } 
 		
 	 return result;
 	 	
}
bool testPigeon(Pigeon & p){
	 std::cout<<"\nTest de la classe Pigeon"<<std::endl;
	 bool result=true;
 	
	 /*
		Je teste si la popularité initiale est entre 0 et 10 et si les méthodes incrementePopularite et decrementePopularite fonctionne;
	 */


	 
	int argentI=p.getsommeArgent();
	result &= p.subirVol();
	p.subirVol();
	result &= !p.subirVol();//Se fait voler trois fois de suite .
 		
 	 return result;
 	 	
}
bool testScenario(Scenario &sc){
	 std::cout<<"\nTest de la méthode Scenario"<<std::endl;
	 bool result=true;
	 /*
	 	Je créer des personnages pour tester la classe
	 */
	 
	 Policier *p=new Policier("Chenbao",sc.carte.lieu[10]);
 	 Pigeon *g=new Pigeon("Afdol",sc.carte.lieu[10]);
	 Gangster *h=new Gangster("yi","dong",sc.carte.lieu[10]);
 	 Gangster *j=new Gangster("luo","dong",sc.carte.lieu[10]);
 	 /*
 	 	Je créer un itineraire pour p
 	 */
 	 p->itineraire.push_back(sc.carte.lieu[10]);//Paris
 	 p->itineraire.push_back(sc.carte.lieu[9]);//Renne
 	 p->itineraire.push_back(sc.carte.lieu[8]);//Quimper
 	 p->itineraire.push_back(sc.carte.lieu[11]);//Bordeaux
 	 

 	 p->setReputation(10);
 	 h->setrecompense(5);//h va être nob
 	 j->setrecompense(50);//J est un master
 	 
	 /*
	 	Je fais le circule pour tester
	 	Et je teste le policier peut retourner au lieu initiale .	
	 */
	 cout<<endl;
	 cout<<"Test sur une iteneraire"<<endl;
	 int depart=p->lieu->getNumero();
 	 p->deplace();//Paris->Renne
 	 p->deplace();//Renne->Quimper
 	 p->deplace();//Quimper->Bordeaux
 	 p->deplace();//Bordeaux->Paris

 	 result &= depart == p->lieu->getNumero();
 	 if(!result){
 	 	cout<<"Des erreur sur votre itineraire"<<endl;
 	 	return 0;
 	 }
 	 
 	 /*
 	 	Tests sur interagir
 	 */
 	 cout<<endl;
 	 cout<<"Test sur interagit"<<endl;
 	 p->interagit(*h);
 	 p->interagit(*j);

	 h->interagit(*j);
	 
	 h->interagit(*g);
	 h->interagit(*g);
 	 h->interagit(*g);//La troisieme ne s'affiche pas "ok";
 	  
 	 
 	 return result;
 	 	
}
	
	
	
	
	
	
	
