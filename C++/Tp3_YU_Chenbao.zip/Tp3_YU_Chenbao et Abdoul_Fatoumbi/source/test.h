#ifndef _TEST_H
#define _TEST_H

#include "lieu.h"
#include "scenario.h"
#include "Gangster.h"
#include "Pigeon.h"
#include "Policier.h"
void testPersonnage();
bool testDeplace(Scenario *sc);
bool testEstAccessible(Scenario *sc);
bool testDistances(Scenario *sc);
bool testPolicier(Policier &p);
bool testGangster(Gangster & p);
bool testPigeon(Pigeon & p);
bool testScenario(Scenario &p);
#endif
