package mini_projet;

public interface Piece_fragile {
	
}
