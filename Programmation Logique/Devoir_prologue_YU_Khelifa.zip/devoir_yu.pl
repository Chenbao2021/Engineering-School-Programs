/*
	Réalisé par :
		Étudiant 1: 	Chen Bao YU, 12012026
		Étudiant 2:	KHELIFA Amel 12110986

*/

/*
	Initialiser les parametres du jeux 
	Le nombre et code des jeux sont susceptible d'etre modifie
*/


couleurs([b,g,j,o,r,v]).
nb_repètes(10).

/*
	Partie I: "génerer une configuration caché"
	Ex:?- cc(X).
	   X = [v, r, g, v].


*/
cc([Couleur1,Couleur2,Couleur3,Couleur4]) :-
	couleurs(BoiteCouleur),
	random_member(Couleur1,BoiteCouleur),
	random_member(Couleur2,BoiteCouleur),
	random_member(Couleur3,BoiteCouleur),
	random_member(Couleur4,BoiteCouleur).

/*
	Partie II : "Compter le nombre des clous noirs"
	Permet de vérifier combien des clous noirs sont crées
	
	-la syntaxe  (A=B) -> C;D. à connaitre
	
	ex:
		?- nb_clous_noir([b,j,g,o],[b,g,j,o],NB).
		NB = 2.
*/

nb_clous_noir(CC,R,NB) :- nb_clous_noir(CC,R,0,NB).
nb_clous_noir([],[],N,N).
nb_clous_noir([HC|TC],[HR|TR],NC,NF) :- ( (HC = HR) -> NNC is NC+1 ,nb_clous_noir(TC,TR,NNC,NF);nb_clous_noir(TC,TR,NC,NF)).


/*
	Partie III: "Trouver nombre des clous totale(Noire+Blanche)"
	Si on a le nombre des fiches noirs et nombres des boules identiques, alors on fait la soustraction et on peut avoir le nombre des fiches blanches .
	
	ex:nb_clous_totale([r,r,r,v],[r,j,v,r],N).
	   N = 3 (1 noire et 2 blancs) 

	
*/

element(X,[X|_]).
element(X,[_|R]) :- element(X,R).

ajout_tete(X,L,[X|L]).

supprimer(_,[],[]).
supprimer(X,[X|L1],L1).
supprimer(X,[Y|L1],L2):-X\==Y , ajout_tete(Y,L3,L2), supprimer(X,L1,L3).

nb_clous_totale(CC,R,N) :- nb_clous_totale(CC,R,0,N).
nb_clous_totale([],_,N,N).
nb_clous_totale([HC|TC],R,NC,NF) :-(element(HC,R)->supprimer(HC,R,Resultat),NCC is NC+1,nb_clous_totale(TC,Resultat,NCC,NF);nb_clous_totale(TC,R,NC,NF)).


/*
	Partie IV: "génerer une requete aléatoire"
	
	-Comme swipl existe déjà random_member , du coup je l'utilise 
	-genere_repete, prend une liste des couleurs, et gènère une liste de taille N, avec des 
	éléments de la liste LC (couleurs:[b,g,j,o,r,v])
	
	ex:	
		?- genere(L).
		L = [o, g, b, r].
*/


taille(4).
genere(L):- taille(N),couleurs(LC),length(L,N),genere_repete(L,LC).

genere_repete([],_).
genere_repete([H|T],LC):- random_member(H,LC),genere_repete(T,LC).

/* 
	Partie V: "Comparer les configurations "
	
	idée:Si config_caché=[r,r,r,r] ,  si le premier_requete donne 2 noirs . Alors la 
	requete_suivant doit avoir exactement 2 noirs avec premier_requete pour espérer d'avoir une 
	meilleur réponse . 
	Ex: Si C1=[r,r,r,b] , donne trois noirs avec Configuration caché 
		Alors C2 ne peut pas etre [r,b,b,b] ,car il a que 2 en commun avec C1.
			Mais [r,r,r,v] c'est possible. 
	Ex:
		?- compart_congfig([a,b,c,d],[a,c,a,b],N,B).
			N = 1,
			B = 2 .
*/

compart_config([],[],_,_).
compart_config(C1,C2,N,B):-nb_clous_noir(C1,C2,N),nb_clous_totale(C1,C2,TOTALE),B is TOTALE-N.

/*
	Partie VI: "Créer une liste qui contient tous les configurations possibles "
	
*/

generer_permutations([Couleur1,Couleur2,Couleur3,Couleur4]) :-
	couleurs(BoiteCouleur),
	member(Couleur1,BoiteCouleur),
	member(Couleur2,BoiteCouleur),
	member(Couleur3,BoiteCouleur),
	member(Couleur4,BoiteCouleur).

/*
	Partie VII: "Supprimer les  configurations mauvaises dans la liste "
	
	idée: Chaque fois que je propose une requete, je vais supprimer des configurations inutiles 
	d'après les informations rapportés par cette requete.
	
	ex:supprime(3,[r,r,j,j],[[r,r,v,j],[j,j,j,j],[j,r,j,j],[r,r,j,j]],New).
	   New = [[r, r, v, j], [j, r, j, j]] 
		Le [r,r,v,j] et [j,j,j,j] sont tous supprimé.	
*/

supprime(_,_,[],[]).
supprime(Nb,C1,[H|T],[H|New]):-compart_config(C1,H,N,_),N=Nb,supprime(Nb,C1,T,New).
supprime(Nb,C1,[H|T],New):-compart_config(C1,H,N,_),not(N=Nb),supprime(Nb,C1,T,New).

/*
	Partie VIII : "Tests avant dernier étape" 
	Résultats du test(New):
	New = [[b, r, r, r], [g, r, r, r], [j, r, r, r], [o, r, r, r], [r, b, r, r], [r, g, r|...], [r, 
		j|...], [r|...], [...|...]|...]
		
	Résultats du test_configuration(C):
	 C = [g, o, j, j].
*/

test(New):-findall(X,generer_permutations(X),L),supprime(3,[r,r,r,r],L,New).
test_configuration(C):-findall(X,generer_permutations(X),L),random_member(C,L).

/*
	Partie IX: Assemblage pour le résultat final.
	
	jouer(Max) : CC=configuration caché, Max=nombre max d'itération
		Il va créer une liste contient tous les configurations possibles
		Choisir une requete aléatoire
		Comparer avec la configuration caché
		Supprimer les configurations inutiles
		Appeler "partie_suivant(,,,,)" pour passer à la requete suivant
	
	partie_suivant(CC,L,Max,Nb):
		CC:configuration caché,L:Liste qui contient l'ensemble des requetes possible
		
		Condition d'arete: Soi depasser MAX fois, soit il a trouvé la bonne requete
		
		Sinon similiaire a la fonction jouer.
*/
jouer(Max):- cc(CC),write("La configuration caché esst :"),write(CC),write("\n"),findall(X,generer_permutations(X),L),random_member(C,L),compart_config(CC,C,N,_),supprime(N,C,L,New),
Tentative is Max-1,partie_suivant(CC,New,Tentative,N,Max).


partie_suivant(_,New,Tentative,4,Max):- R is Max-Tentative,write(R),write(" Tentatives,et la configuration caché:"),write(New).
partie_suivant(CC,L,Max,_,M):-Max>0,random_member(C,L),compart_config(CC,C,N,B),write("requête:"),write(C),write(",(noir,blanc)="),write(N),write(","),write(B),write("\n"),supprime(N,C,L,New),Tentative is Max-1,partie_suivant(CC,New,Tentative,N,M).

